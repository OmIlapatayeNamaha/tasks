from rest_framework import viewsets
from rest_framework.response import Response

class ExampleViewSet(viewsets.ViewSet):
    def list(self, request):
        response_data = {
            'message': 'This is an example endpoint',
            'data': {
                'key': 'value'
            }
        }
        return Response(response_data)
