from django.urls import include, path
from rest_framework import routers
from app.views import ExampleViewSet
from rest_framework_swagger.views import get_swagger_view

router = routers.DefaultRouter()
router.register(r'example', ExampleViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('docs/', get_swagger_view(title='API Documentation')),
]
